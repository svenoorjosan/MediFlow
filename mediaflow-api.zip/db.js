// src/api/db.js
import { MongoClient } from 'mongodb';

let client;
let collection;

export async function jobs() {
  if (collection) return collection;

  const uri = process.env.COSMOS_URI;
  const dbName = process.env.COSMOS_DB || 'mediaflow';
  const collName = process.env.COSMOS_COLL || 'jobs';

  if (!uri) throw new Error('COSMOS_URI is not set');

  client ||= new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  await client.connect();

  const db = client.db(dbName);
  collection = db.collection(collName);
  return collection;
}
