import express from 'express';
import multer from 'multer';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  BlobServiceClient,
  StorageSharedKeyCredential,
  BlobSASPermissions,
  generateBlobSASQueryParameters
} from '@azure/storage-blob';
import { jobs } from './db.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// ESM-friendly __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/* ── Serve the minimal UI from /public ──────────────────────── */
app.use(
  express.static(path.join(__dirname, 'public'), {
    maxAge: '1h',
    etag: true,
  })
);
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/* ── Multer: keep uploads in memory ─────────────────────────── */
const upload = multer({ storage: multer.memoryStorage() });

/* ── Lazy Blob client (safer startup) ───────────────────────── */
function getContainerClient() {
  const conn = process.env.AZURE_STORAGE_CONNECTION_STRING;
  const name = process.env.AZURE_STORAGE_CONTAINER || 'uploads';
  if (!conn) throw new Error('AZURE_STORAGE_CONNECTION_STRING not set');
  return BlobServiceClient.fromConnectionString(conn).getContainerClient(name);
}

/* ── Small helpers ──────────────────────────────────────────── */
function parseStorageConn(conn) {
  const g = (k) => (new RegExp(`${k}=([^;]+)`).exec(conn) || [])[1];
  return { accountName: g('AccountName'), accountKey: g('AccountKey') };
}

// Build a READ-only SAS URL (default 15 minutes)
function makeReadSasUrl(containerName, blobName, minutes = 15) {
  const conn = process.env.AZURE_STORAGE_CONNECTION_STRING;
  const { accountName, accountKey } = parseStorageConn(conn);
  if (!accountName || !accountKey) {
    throw new Error('AccountName/AccountKey missing in storage connection string');
  }
  const credential = new StorageSharedKeyCredential(accountName, accountKey);
  const startsOn = new Date(Date.now() - 60 * 1000);          // 1 min clock skew
  const expiresOn = new Date(Date.now() + minutes * 60 * 1000);

  const sas = generateBlobSASQueryParameters(
    {
      containerName,
      blobName,
      permissions: BlobSASPermissions.parse('r'),
      startsOn,
      expiresOn
    },
    credential
  ).toString();

  return `https://${accountName}.blob.core.windows.net/${containerName}/${encodeURIComponent(blobName)}?${sas}`;
}

/* ── Routes ─────────────────────────────────────────────────── */
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// Used by the footer links (non-critical; safe if it 404s)
app.get('/api/config', (_req, res) => {
  const conn = process.env.AZURE_STORAGE_CONNECTION_STRING || '';
  const { accountName } = parseStorageConn(conn);
  const blobBaseUrl = accountName
    ? `https://${accountName}.blob.core.windows.net`
    : null;

  res.json({
    apiBase: `${_req.protocol}://${_req.get('host')}`,
    blobBaseUrl,
    uploadsContainer: process.env.AZURE_STORAGE_CONTAINER || 'uploads',
    thumbsContainer: 'thumbnails'
  });
});

app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'no file' });

    const containerClient = getContainerClient();
    const containerName = containerClient.containerName;

    const safeName = req.file.originalname.replace(/[^\w.\-]/g, '_');
    const blobName = `${Date.now()}-${safeName}`;
    const blockBlob = containerClient.getBlockBlobClient(blobName);

    await blockBlob.uploadData(req.file.buffer, {
      blobHTTPHeaders: { blobContentType: req.file.mimetype || 'application/octet-stream' },
    });

    // Optional metadata for downstream (not required)
    try { await blockBlob.setMetadata({ jobId: blobName }); } catch { }

    // record job
    const coll = await jobs();
    await coll.insertOne({
      id: blobName,          // shard key / lookup key
      _id: blobName,
      url: blockBlob.url,    // raw (private) URL for internal use
      original: req.file.originalname,
      status: 'queued',
      createdAt: new Date(),
    });

    // return short-lived read SAS to the client
    const readUrl = makeReadSasUrl(containerName, blobName, 15);

    res.json({
      id: blobName,
      url: readUrl,          // signed URL (works with public access disabled)
      original: req.file.originalname,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || 'upload failed' });
  }
});

// polled by the UI until thumbUrl appears
// add (or reuse) this env for consistency with worker
const THUMBS = process.env.THUMBS_CONTAINER || 'thumbnails';

app.get('/api/job/:id', async (req, res) => {
  try {
    const coll = await jobs();
    const doc = await coll.findOne({ _id: req.params.id });
    if (!doc) return res.status(404).json({ error: 'not found' });

    if (doc.status !== 'done') {
      return res.json({ id: doc.id, status: doc.status || 'queued', thumbUrl: null });
    }

    const thumbName = `${doc.id}.thumb.jpg`;          // worker naming
    const signed = makeReadSasUrl(THUMBS, thumbName, 15); // 15-min read SAS
    return res.json({ id: doc.id, status: 'done', thumbUrl: signed });
  } catch (e) {
    res.status(500).json({ error: e?.message || 'lookup failed' });
  }
});


app.listen(port, () => {
  console.log(`API listening on :${port}`);
  console.log('Env sanity:', {
    STORAGE_CONTAINER: process.env.AZURE_STORAGE_CONTAINER,
    COSMOS_DB: process.env.COSMOS_DB,
    COSMOS_COLL: process.env.COSMOS_COLL,
  });
});
