(() => {
  const apiBaseEl = document.getElementById('apiBase');
  const uploadsLink = document.getElementById('uploadsLink');
  const thumbsLink = document.getElementById('thumbsLink');
  const copyBtn = document.getElementById('copyId');
  const outEl = document.getElementById('out');
  const statusEl = document.getElementById('status');
  const barEl = document.getElementById('bar');
  const drop = document.getElementById('drop');
  const fileInput = document.getElementById('file');
  const pickBtn = document.getElementById('pickBtn');
  const thumbBox = document.getElementById('thumbBox');
  const thumbImg = document.getElementById('thumbImg');

  let apiBase = location.origin;
  let lastId = null;

  // Load config to wire helpful links
  fetch('/api/config').then(r => r.json()).then(cfg => {
    apiBase = cfg.apiBase || apiBase;
    apiBaseEl.textContent = apiBase.replace(/^https?:\/\//, '');
    if (cfg.blobBaseUrl) {
      uploadsLink.href = `${cfg.blobBaseUrl}/${cfg.uploadsContainer || 'uploads'}/`;
      thumbsLink.href = `${cfg.blobBaseUrl}/${cfg.thumbsContainer || 'thumbnails'}/`;
    } else {
      uploadsLink.removeAttribute('href');
      thumbsLink.removeAttribute('href');
    }
  }).catch(() => { /* non-fatal */ });

  pickBtn.addEventListener('click', () => fileInput.click());

  // Drag & drop
  ;['dragenter', 'dragover'].forEach(evt => {
    drop.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); drop.classList.add('dragover'); });
  });
  ;['dragleave', 'drop'].forEach(evt => {
    drop.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); drop.classList.remove('dragover'); });
  });
  drop.addEventListener('drop', e => {
    const f = e.dataTransfer.files?.[0];
    if (f) uploadFile(f);
  });

  fileInput.addEventListener('change', () => {
    const f = fileInput.files?.[0];
    if (f) uploadFile(f);
  });

  copyBtn.addEventListener('click', async () => {
    if (!lastId) return;
    await navigator.clipboard.writeText(lastId);
    copyBtn.textContent = 'Copied!';
    setTimeout(() => (copyBtn.textContent = 'Copy job id'), 1200);
  });

  function setProgress(pct) {
    barEl.style.width = `${pct}%`;
  }

  function showResult(obj) {
    outEl.textContent = JSON.stringify(obj, null, 2);
  }

  function pollJob(id) {
    const iv = setInterval(async () => {
      try {
        const r = await fetch(`/api/job/${encodeURIComponent(id)}`);
        if (!r.ok) return;
        const j = await r.json();
        if (j.thumbUrl) {
          clearInterval(iv);
          statusEl.textContent = 'Done.';
          thumbImg.src = j.thumbUrl;
          thumbBox.style.display = 'block';
        } else {
          statusEl.textContent = `Processing… (status: ${j.status || 'queued'})`;
        }
      } catch { }
    }, 1500);
  }

  function uploadFile(file) {
    thumbBox.style.display = 'none';
    thumbImg.removeAttribute('src');
    statusEl.textContent = 'Uploading…';
    setProgress(0);
    outEl.textContent = '(uploading…)';
    copyBtn.disabled = true;
    lastId = null;

    const fd = new FormData();
    fd.append('file', file);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload', true);

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 100);
        setProgress(pct);
      }
    };

    xhr.onload = () => {
      try {
        const data = JSON.parse(xhr.responseText);
        showResult(data);
        if (data.id) {
          lastId = data.id;
          copyBtn.disabled = false;
          statusEl.textContent = 'Queued. Waiting for thumbnail…';
          pollJob(data.id);
        } else if (data.error) {
          statusEl.textContent = `Error: ${data.error}`;
        } else {
          statusEl.textContent = 'Uploaded.';
        }
      } catch (e) {
        statusEl.textContent = 'Upload finished, but response was not JSON.';
      }
      setProgress(100);
    };

    xhr.onerror = () => {
      statusEl.textContent = 'Upload failed.';
    };

    xhr.send(fd);
  }
})();
